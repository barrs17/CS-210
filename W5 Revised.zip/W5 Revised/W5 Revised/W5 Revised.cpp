
/*
Author: Seth Barr
Date: 5 December 2023
*/
#include <iostream>
#include <iomanip>

using namespace std;

int main() {
	//Declare variables 
	float initialInvestment;
	float annualInterestRate;
	float monthlyDeposit;
	float years;
	float totalAmount;
	float interestAmount;
	float compoundInterest;

	std::cout << "Welcome to the Airgead Banking Investment Calculator\n";
	
	//Get data from the user
	cout << "\n";
	cout << "Data Input \n";
	cout << "Initial Investment Amount: $";
	cin >> initialInvestment;
	cout << "Monthly Deposit: $";
	cin >> monthlyDeposit;
	cout << "Annual Interest: %";
	cin >> annualInterestRate;
	cout << "Number of years: ";
	cin >> years;
	
	totalAmount = initialInvestment;

	// Display investment growth
	cout << "\nBalance and Interest Without Additional Monthly Deposits\n";
	cout << "=\n";
	cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
	cout << "-\n";
	for (int i = 0; i < years; i++) {

		//Calculate yearly interest
		interestAmount = (totalAmount) * ((annualInterestRate / 100));
		//Calculate year end total
		totalAmount = totalAmount + interestAmount;

		//Print results
		cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAmount << "\t\t\t$" << interestAmount << "\n";
	}

	totalAmount = initialInvestment;

	//Display data with monthly deposit
	cout << "\n\nBalance and Interest With Additional Monthly Deposits\n";
	cout << "=\n";
	cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
	cout << "-\n";
	for (int i = 0; i < years; i++) {
		//Set yearly interest to zero at the start of the year
		compoundInterest = 0;
		for (int j = 0; j < 12; j++) {

			//Calculate monthly interest
			interestAmount = (totalAmount + monthlyDeposit) * ((annualInterestRate / 100) / 12);

			//Calculate month end interest
			compoundInterest = compoundInterest + interestAmount;

			//Calculate month end total
			totalAmount = totalAmount + monthlyDeposit + interestAmount;

		}
		//Print results 
		cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAmount << "\t\t\t$" << compoundInterest << "\n";
	}
	//Choice for another calculation
	char choice;
	std::cout << "Do you want to calculate another investment? (y/n): ";
	std::cin >> choice;

	if (choice == 'y' || choice == 'Y') {
		// Loop
		main();
	}
	return 0;
}